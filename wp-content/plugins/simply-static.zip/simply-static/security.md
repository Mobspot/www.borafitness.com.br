# Security Policy

## Reporting Security Bugs

Please report security bugs found in this project's source code through the [Patchstack Vulnerability Disclosure Program](https://patchstack.com/database/vdp/simply-static). The Patchstack team will assist you with verification, CVE assignment and take care of notifying the developers of this plugin.