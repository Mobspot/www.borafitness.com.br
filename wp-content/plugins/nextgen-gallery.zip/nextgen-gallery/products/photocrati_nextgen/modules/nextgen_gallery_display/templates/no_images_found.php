<p><?php esc_html_e('no images were found', 'nextgen-gallery'); ?></p>
