<span class="field gallery_description_field">
	<textarea name="galdesc" id="gallery_description"><?php echo esc_html($gallery->galdesc) ?></textarea>
</span>